
package logica.interfaces;


public class InterfazUsuarioDAO {

}
