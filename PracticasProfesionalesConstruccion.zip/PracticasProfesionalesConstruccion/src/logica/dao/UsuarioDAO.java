
package logica.dao;


public class UsuarioDAO {

}
