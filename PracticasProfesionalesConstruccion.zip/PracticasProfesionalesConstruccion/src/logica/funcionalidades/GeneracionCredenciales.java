
package logica.funcionalidades;


public class GeneracionCredenciales {

}
