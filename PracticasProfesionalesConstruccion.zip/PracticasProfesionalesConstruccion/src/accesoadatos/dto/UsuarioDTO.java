
package accesoadatos.dto;

public class UsuarioDTO {
    
    

}
